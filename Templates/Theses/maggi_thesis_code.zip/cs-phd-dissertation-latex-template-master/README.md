Latex Template for PhD Dissertations
====================================

Latex template based on the typographic memoir class for formatting PhD
dissertations. Suitable for any areas but devised for computer science
researchers.

Usage
-----
Simply run `xelatex thesis` to make it. You may need to run `bibtex thesis` and
then `xelatex thesis` (twice) the first time you build it.
